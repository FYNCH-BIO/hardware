BOSTON UNIVERSITY EDF
eVOLVER System

EV-Vial Rev B

2 layers
0.063 final thickness FR-4
1 oz copper
soldermask both sides (BLACK) <---- NOTE: Black Solder mask!
silkscreen legend top only (white)

Contact:  Chris Lawlor / 617-353-4117 / cjlawlor@bu.edu

Vial_Board-F.Cu.gbr        Layer 1 (positive)
Vial_Board-B.Cu.gbr        Layer 2 (positive)
Vial_Board-B.Mask.gbr      Bottom solder mask
Vial_Board.drl             NC drill (plated)
Vial_Board-Dwgs.User.gbr   Fab drawing
Vial_Board-F.Mask.gbr      Top solder mask
Vial_Board-F.SilkS.gbr     Top silkscreen
Vial_Board-NPTH.drl        NC drill (unplated)

