BOSTON UNIVERSITY EDF
eVOLVER System

EV-AuxB Rev B

4 layers
0.063 final thickness FR-4
1 oz copper
soldermask both sides (green)
silkscreen legent top only (white)

Contact:  Chris Lawlor / 617-353-4117 / cjlawlor@bu.edu

Auxiliary_Board-F.Mask.gbr            Solder mask (same both sides)
Auxiliary_Board-F.SilkS.gbr           Top silkscreen
Auxiliary_Board-F.Cu.gbr              Layer 1 (positive)
Auxiliary_Board-In1.Cu.gbr            Layer 2 (positive)
Auxiliary_Board-In2.Cu.gbr            Layer 3 (positive)
Auxiliary_Board-B.Cu.gbr              Layer 4 (positive)
Auxiliary_Board.drl                   NC Drill (plated)
Auxiliary_Board-NPTH.drl              NC Drill (unplated)
Auxiliary_Board-Dwgs.User.gbr         Fab drawing
