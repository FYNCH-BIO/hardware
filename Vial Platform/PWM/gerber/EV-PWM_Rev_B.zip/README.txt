BOSTON UNIVERSITY EDF
eVOLVER System

P/N EV-PWM Rev A
4 Layers FR-4
0.063 final thickness
1 oz copper
soldermask both sides (green)
silkscreen legend top only (white)

Contact:  Chris Lawlor / 617-353-4117 / cjlawlor@bu.edu

eVolver_pwm-F.Cu.gbr                  Layer 1 (positive)
eVolver_pwm-In1.Cu.gbr                Layer 2 (positive)
eVolver_pwm-In2.Cu.gbr                Layer 3 (positive)
eVolver_pwm-B.Cu.gbr                  Layer 4 (positive)
eVolver_pwm-B.Mask.gbr                Bottom solder mask
eVolver_pwm.drl                       NC drill (plated)
eVolver_pwm-Dwgs.User.gbr             Fab drawing
eVolver_pwm-F.Mask.gbr                Top solder mask
eVolver_pwm-F.SilkS.gbr               Top silkscreen
eVolver_pwm-F.Paste.gbr               Top solder paste
eVolver_pwm-all.pos                   Component placement
