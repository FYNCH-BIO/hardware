BOSTON UNIVERSITY EDF
eVOLVER System

P/N EV-MB Rev B
4 Layer FR-4
Final Thickness 0.063
1 oz copper
Soldermask both sides (green)
Silkscreen legend top only (white)

Contact for all issues:  Chris Lawlor / 617-353-4117 / cjlawlor@bu.edu

Motherboard.drl                NC Drill
Motherboard-F.SilkS.gbr        Top silkscreen
Motherboard-F.Mask.gbr         Soldermask (same both sides)
Motherboard-F.Cu.gbr           Layer 1 copper (positive)
Motherboard-In1.Cu.gbr         Layer 2 copper (positive)
Motherboard-In2.Cu.gbr         Layer 3 copper (positive)
Motherboard-B.Cu.gbr           Layer 4 copper (positive)
Motherboard-Dwgs.User.gbr      Fab drawing

