Boston University P/N EV-PiHat Rev A

2 Layers FR-4
0.063 in finished thickness
1 oz copper
Soldermask both sides (green)
Silkscreen front side (white)
